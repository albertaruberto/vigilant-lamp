package januarycar1example30january2018;



import java.util.Scanner;

public class januarycar1example30january2018class1 {

	
	
	private static Scanner in;

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//buy the component of the car
		   //price1 = component
		   //price2 = chassis
		   //price3 = transmission
		
		// drive the car
		// calculate the price pro km
		
		
		
		double price1, price2, price3, totalCost;
		
		in = new Scanner (System.in);
		System.out.println("Enter the price of components: ");
			price1 = in.nextDouble();
		
		System.out.println("Enter the price of chassis: ");
	        price2 = in.nextDouble();
	    System.out.println("Enter the price of transmission: ");
	        price3 = in.nextDouble();
	        
		totalCost = (price1 + price2 + price3);
		
	
		
		  System.out.println("The price of the car is:");
		
		  
		   System.out.println(totalCost);
		   
	  
		   
		   if (totalCost <= 20)
			   
		   {
			  System.out.println("You have buy a cheap car:");
			
		   }
		   
		   if (totalCost <= 20)
			   
			   
		   {
		
		   System.out.println("You save 0 CHF:");
		   
		   }
		   
		   if (totalCost <=100)
		   
		   if (totalCost >20)
		   {
				  System.out.println("You have buy a good car:");
		   } 
		   
		  
		   
		   if (totalCost <=100)
			   
		   if (totalCost >20)
		   {
			   
			   totalCost = totalCost -10;
			   
			   System.out.println("You save 10 CHF of the price:");
			
			   
		   }
				  
		   
		
		   
		   
		   if (totalCost > 101)   
			   
		   {
			 
			   System.out.println("You have buy an expansive car:");
			   
			   totalCost = totalCost -50;
			   
			   System.out.println("You save 50 CHF of the price:"); 
			   
			   
		   } 
		 
		   
			   	
			    System.out.println("Total cost for your car is: "+totalCost);
			    
			    
		   

		   System.out.println("Now drive your car: ");
		 
		   
		   
		   }
		   
		   
	
	
		   
		   
		   }
		   
		   


		
	

		  
